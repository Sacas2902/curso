package udb.net.mod1.spring;

public class EmpleadoServicio extends Empleado {
	private String nombreEmpleadoServicio;
	private String apellidoEmpleadoServicio;
	private String comercio;

	public EmpleadoServicio() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmpleadoServicio(String nombre, String apelllido, Double salario) {
		super(nombre, apelllido, salario);
		// TODO Auto-generated constructor stub
	}

	public String getComercio() {
		return comercio;
	}

	public void setComercio(String comercio) {
		this.comercio = comercio;
	}

	@Override
	Double calculoSalarioNeto() {
		// TODO Auto-generated method stub
		return getSalario() - (getSalario() * 0.10);
	}

	public String getNombreEmpleadoServicio() {
		return nombreEmpleadoServicio;
	}

	public void setNombreEmpleadoServicio(String nombreEmpleadoServicio) {
		this.nombreEmpleadoServicio = nombreEmpleadoServicio;
	}

	public String getApellidoEmpleadoServicio() {
		return apellidoEmpleadoServicio;
	}

	public void setApellidoEmpleadoServicio(String apellidoEmpleadoServicio) {
		this.apellidoEmpleadoServicio = apellidoEmpleadoServicio;
	}
}
