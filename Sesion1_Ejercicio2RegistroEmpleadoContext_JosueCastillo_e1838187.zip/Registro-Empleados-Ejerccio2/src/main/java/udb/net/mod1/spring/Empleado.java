package udb.net.mod1.spring;

public abstract class Empleado {
	private String nombre;
	private String apelllido;
	private  Double salario;

	public Empleado(String nombre, String apelllido, Double salario) {
		super();
		this.nombre = nombre;
		this.apelllido = apelllido;
		this.salario = salario;
	}
	public Empleado() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApelllido() {
		return apelllido;
	}
	public void setApelllido(String apelllido) {
		this.apelllido = apelllido;
	}

	
	abstract Double calculoSalarioNeto();
	public Double getSalario() {
		return salario;
	}
	public Double setSalario(Double salario) {
		return this.salario = salario;
	}

}
