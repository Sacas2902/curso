package udb.net.mod1.spring;

public class EmpleadoAsalariado extends Empleado{

	private String nombre;
	private String apellido;
	private String cargo;
	public EmpleadoAsalariado() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmpleadoAsalariado(String nombre, String apelllido, Double saldo) {
		super(nombre, apelllido, saldo);
		// TODO Auto-generated constructor stub
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	@Override
	Double calculoSalarioNeto() {
		
		return getSalario()-getSalario()*0.20;
				}
	
	
}
