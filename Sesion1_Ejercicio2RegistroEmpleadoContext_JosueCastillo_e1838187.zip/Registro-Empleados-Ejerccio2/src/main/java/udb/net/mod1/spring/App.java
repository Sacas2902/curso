package udb.net.mod1.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class App {

	public static void main(String[] args) {

		ApplicationContext cont = new FileSystemXmlApplicationContext("src/main/resources/applicationContext.xml");

		Empleado em1 = cont.getBean(EmpleadoServicio.class);
		Empleado em2 = cont.getBean(EmpleadoComerciante.class);

		System.out.println("El empleado por  Servicio es:\n");
		imprimir(em1);
		System.out.println("**************************************************");
		System.out.println("El empleado  comerciantes es:\n");
		imprimir(em2);

	}

	public static void imprimir(Empleado e) {

		System.out.println("Nombre  del Empleado  es " + e.getNombre());
		System.out.println("Apellido  del Empleado  es " + e.getApelllido());
		System.out.println("Su salario  es Neto es  " + e.calculoSalarioNeto());

	}
}
