package udb.net.mod1.spring;

public class EmpleadoComerciante extends Empleado {
	private  String nombre;
	private  String apellido;
	private  String comercio;
	public EmpleadoComerciante() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmpleadoComerciante(String nombre, String apelllido, Double salario) {
		super(nombre, apelllido, salario);
		// TODO Auto-generated constructor stub
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getComercio() {
		return comercio;
	}
	public void setComercio(String comercio) {
		this.comercio = comercio;
	}
	@Override
	Double calculoSalarioNeto() {
		Double  costo=150.00;
		
		Double ingreso=getSalario();
		// TODO Auto-generated method stub
		return  ingreso-costo;
	} 
}
